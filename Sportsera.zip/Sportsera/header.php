<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<script type="text/javascript" src="NewUser.js"></script> <!--Linking the javaScript-->
		<link rel="stylesheet" href="Style.css"/>   <!--Linking the style sheet used-->
     <title> Sportsera </title>
	 </head>
	 
	 <body>
	   <div id="Container">
	     <div id="Header">
		   Sportsera <!-- Header displaying Website name-->
		 </div>
		 <div id="Content">
<?php
require_once 'menu.php';

		 