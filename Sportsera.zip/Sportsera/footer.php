 		 </div>
 		 <!--Footer details-->	
		 <div id="Footer">
		 Copyright @ 2014 Sportsera
                   </br>All Rights Reserved
		 </div>
	   </div>
	 </body>
	 </html>