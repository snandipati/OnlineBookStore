Installation 
1. The db installatoin script is present in sportsera.sql.
2. In mysql commandt line run "source pageturners.sql"

Settings
Set "thread_stack = 256K" in my.cnf for the mysql configuration. 

Assumptions

1. A given user has only one phone number . 
2. The user's billing address and shipping address is the same. 

Admin Access :

Username : silpa@sportsera.com
Password: hello

Registered USer Access:

username : goutham@sportsera.com
Password: test
username : vamsi@yahoo.com
Password: test


