<?php
require_once 'lib.php';
require_once 'header.php';
?>
 <div id="PageSection">
      <!-- Contact information-->
                    <h3> Contact us : </h3>
                    <p> Email us @ : silpa.nandipati1@gmail.com </p>
					<p> Phone : 408-431-2302 </p>
					<p> Street: Sunnyvale</p>
					<p> City : SantaClara </p>
					<p> ZipCode : 94086 </p>
					<br></br>
					<p>
					<!-- little description about the Sportsera online store.-->
					About us : Sportsera is a major online Sports store selling variety of Sport items. 
					We sell various categories of  Fitness, Clothes, Shoes, Accessories, Teamsports, Games and Outdoors sport items. 
                    Please signup and save 5% Now. The league. Get 5% back.
					</p>
 </div>
<?php 
require_once 'footer.php';
					