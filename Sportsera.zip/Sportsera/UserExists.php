<?php 
require_once 'lib.php';
require_once 'db.php';
require_once 'header.php';
 ?>
             <!--Error message -->
			 <div id="PageSection">
			 <h4> Sorry! User with this Email already Exists!! </h4>
			 <h2> Please try to Sign up with a different Email. </h2>
			 </div>
<?php
require_once 'footer.php'; 
?>